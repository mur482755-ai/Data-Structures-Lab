#include <iostream>
using namespace std;

class inventory {
public:
    int serialNo;
    int year;
    int lotNo;

    void input() {
        cout << "enter serial no: ";
        cin >> serialNo;
        cout << "enter year: ";
        cin >> year;
        cout << "enter lot no: ";
        cin >> lotNo;
    }

    void display() {
        cout << "serial no: " << serialNo << " year: " << year << " lot no: " << lotNo << endl;
    }
};

struct node {
    inventory data;
    node* next;
};

class stack {
    node* topPtr;

public:
    stack() {
        topPtr = NULL;
    }

    void push(inventory x) {
        node* temp = new node;
        temp->data = x;
        temp->next = topPtr;
        topPtr = temp;
    }

    void pop() {
        if (topPtr == NULL) {
            cout << "stack empty" << endl;
        } else {
            node* rem = topPtr;
            cout << "removed: ";
            rem->data.display();
            topPtr = topPtr->next;
            delete rem;
        }
    }

    void show() {
        node* cur = topPtr;
        cout << "remaining items:" << endl;
        while (cur != NULL) {
            cur->data.display();
            cur = cur->next;
        }
    }
};

int main() {
    stack s;
    inventory x;
    int choice;

    do {
        cout << "1 add, 2 remove, 0 exit: ";
        cin >> choice;

        if (choice == 1) {
            x.input();
            s.push(x);
        } else if (choice == 2) {
            s.pop();
        }

    } while (choice != 0);

    s.show();

    return 0;
}