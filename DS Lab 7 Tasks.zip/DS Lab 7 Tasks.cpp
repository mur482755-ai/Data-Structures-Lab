#include <iostream>
using namespace std;

class Book {
public:
    string title;
    float price;
    int edition;
    int pages;

    void input() {
        cout << "Enter book title: ";
        cin >> title;
        cout << "Enter price: ";
        cin >> price;
        cout << "Enter edition: ";
        cin >> edition;
        cout << "Enter pages: ";
        cin >> pages;
    }

    void show() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
        cout << "Edition: " << edition << endl;
        cout << "Pages: " << pages << endl;
    }
};

class Stack {
public:
    Book arr[5];
    int top;

    Stack() {
        top = -1;
    }

    void push(Book b) {
        if (top == 4) {
            cout << "* Stack full, cannot add more books *" << endl;
        } else {
            top++;
            arr[top] = b;
            cout << endl;
            cout << "* Book added successfully *" << endl;
            cout << endl;
        }
    }

    void pop() {
        if (top == -1) {
            cout << "* Stack empty, nothing to remove *" << endl;
        } else {
            cout << "* Removing book: " << arr[top].title << " *" << endl;
            top--;
        }
    }

    void peek() {
        if (top == -1) {
            cout << "* Stack is empty *" << endl;
        } else {
            cout << "* Top book is *" << endl;
            arr[top].show();
        }
    }

    void display() {
        if (top == -1) {
            cout << "* Stack is empty *" << endl;
            cout << endl;
            
        } else {
            cout << "* Remaining books in stack *" << endl;
            cout << endl;
            for (int i = top; i >= 0; i--) {
                arr[i].show();
                cout << "********************" << endl;
            }
        }
    }
};

int main() {
    Stack s;
    Book b;

    cout << "* Enter 5 books data *" << endl;
	cout << endl;
	
    for (int i = 0; i < 5; i++) {
        cout << "* Book " << i + 1 << " *" << endl;
        cout << endl;
        b.input();
        s.push(b);
    }

    cout << "* Checking top book *" << endl;
    s.peek();
	cout << endl;

    cout << "* Removing 2 books *" << endl;
    s.pop();
    s.pop();
	cout << endl;

    cout << "* Showing remaining books *" << endl;
    s.display();

    return 0;
}