#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* front = NULL;
Node* rear = NULL;

void insertRear() {
    Node* newNode = new Node();

    cout << "Enter value is: ";
    cin >> newNode->data;

    newNode->next = NULL;

    if (rear == NULL) {
        front = rear = newNode;
    } else {
        rear->next = newNode;
        rear = newNode;
    }

    cout << "Value is inserted at rear" << endl;
}

void deleteFront() {
    if (front == NULL) {
        cout << "Queue is empty" << endl;
    } else {
        Node* temp = front;
        cout << "Deleted value is: " << temp->data << endl;
        front = front->next;

        if (front == NULL)
            rear = NULL;

        delete temp;
    }
}

void display() {
    if (front == NULL) {
        cout << "Queue is empty" << endl;
    } else {
        Node* temp = front;
        cout << "Queue elements are: ";

        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
}

int main() {
    insertRear();
    insertRear();
    display();
    deleteFront();
    display();

    return 0;
}