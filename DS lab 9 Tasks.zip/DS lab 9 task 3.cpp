#include <iostream>
using namespace std;

const int SIZE = 5;

int queueArr[SIZE];
int front = -1;
int rear = -1;

void enqueue(int value) {
    if (rear == SIZE - 1) {
        cout << "Queue is full" << endl;
    } else {
        if (front == -1) {
            front = 0;
        }

        rear = rear + 1;
        queueArr[rear] = value;
    }
}

int countElements() {
    if (front == -1 || front > rear) {
        return 0;
    } else {
        return rear - front + 1;
    }
}

void display() {
    if (front == -1 || front > rear) {
        cout << "Queue is empty" << endl;
    } else {
        cout << "Queue elements are: ";
        for (int i = front; i <= rear; i++) {
            cout << queueArr[i] << " ";
        }
        cout << endl;
    }
}

int main() {
    enqueue(10);
    enqueue(20);
    enqueue(30);

    display();

    cout << "Total number of elements is: " << countElements() << endl;

    return 0;
}