#include <iostream>
using namespace std;

const int SIZE = 5;

int queueArr[SIZE];
int front = -1, rear = -1;

void enqueue() {
    if (rear == SIZE - 1) {
        cout << "Queue is full" << endl;
    } else {
        int value;
        cout << "Enter value is: ";
        cin >> value;

        if (front == -1)
            front = 0;

        rear++;
        queueArr[rear] = value;

        cout << "Value is inserted" << endl;
    }
}

void dequeue() {
    if (front == -1 || front > rear) {
        cout << "Queue is empty" << endl;
    } else {
        cout << "Deleted value is: " << queueArr[front] << endl;
        front++;
    }
}

void display() {
    if (front == -1 || front > rear) {
        cout << "Queue is empty" << endl;
    } else {
        cout << "Queue elements are: ";
        for (int i = front; i <= rear; i++) {
            cout << queueArr[i] << " ";
        }
        cout << endl;
    }
}

int main() {
    int choice;

    do {
        cout << endl;
        cout << "1. Enqueue" << endl;
        cout << "2. Dequeue" << endl;
        cout << "3. Display" << endl;
        cout << "4. Exit" << endl;

        cout << "Enter choice is: ";
        cin >> choice;

        if (choice == 1)
            enqueue();
        else if (choice == 2)
            dequeue();
        else if (choice == 3)
            display();

    } while (choice != 4);

    return 0;
}