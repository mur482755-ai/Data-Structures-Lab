#include<iostream>
using namespace std;

int main(){
	
	int array[5]= {70,80,90,100,110};
	
	int*ptr=array;
	
	for(int i=0; i<5; i++){
		
		cout << "Element of array " << i  << " : " << * (ptr + i) << endl;
		
	}
	
return 0;
	
}
