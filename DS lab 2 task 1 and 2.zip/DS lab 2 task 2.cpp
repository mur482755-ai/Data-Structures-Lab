#include<iostream>
using namespace std;

void SWAPIntegers(int *c , int *d){
	
	int temp = *c;
	
	*c = *d;

	*d=  temp;
}

int main(){
	
	int x=200;  int y = 500;
	
	cout << " Before swapping value of x =" << x   <<"   " << "and "<< " y = " << y << endl;
	
  SWAPIntegers( &x , &y);
	
	cout << " After swapping values  x = " << x   <<"  " << "and " << " y = " << y << endl;
	 

	 return 0;
}
