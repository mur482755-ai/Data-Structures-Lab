#include <iostream>
using namespace std;

int main() {
    int num, key;
    cout << "Enter number of elements: ";
    cin >> num;

    int arr[num];
    cout << "Enter elements:\n";
    for(int i = 0; i < num; i++) {
        cin >> arr[i];
    }

    cout << "Enter element to search: ";
    cin >> key;

    for(int i = 0; i < num; i++) {
        if(arr[i] == key) {
            cout << "Element found at index: " << i;
            return 0;
        }
    }

    cout << "Element not found";
    return 0;
}
