#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter the  number of elements: ";
    cin >> num;

    int arr[num];
    cout << "Enter elements \n";
    for (int i = 0; i < num; i++) {
        cin >> arr[i];
    }


    for (int i = 0; i < num / 2; i++) {
        int temp = arr[i];
        arr[i] = arr[num - 1 - i];
        arr[num - 1 - i] = temp;
    }

    cout << "Reversed array";
    for (int i = 0; i < num; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
