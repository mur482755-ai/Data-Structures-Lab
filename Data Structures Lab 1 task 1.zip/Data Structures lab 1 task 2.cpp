#include <iostream>
using namespace std;

int main() {
    int num, index, value;
    cout << "Enter the  number of elements: ";
    cin >> num;

    int arr[num];
    cout << "Enter elements:\n";
    for(int i = 0; i < num; i++) {
        cin >> arr[i];
    }

    cout << "Enter the  index to update: ";
    cin >> index;

    cout << "Enter  the new value: ";
    cin >> value;

    if(index >= 0 && index < num) {
        arr[index] = value;
        cout << "Updated array:\n";
        for(int i = 0; i < num; i++) {
            cout << arr[i] << " ";
        }
    } else {
        cout << "Invalid index";
    }

    return 0;
}
