#include <iostream>
using namespace std;


struct MNode {
    string br;     
    int qty;        
    float price;   
    MNode* next;    
};

MNode* head = NULL;


void addMob(string b, int q, float p) {
    MNode* nn = new MNode;
    nn->br = b;
    nn->qty = q;
    nn->price = p;
    nn->next = NULL;

    if (head == NULL) {
        head = nn;
    } else {
        MNode* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = nn;
    }
}


void delMob(string b) {
    if (head == NULL) {
        cout << "Inventory is Empty!"  << endl;
        return;
    }

    MNode* temp = head;
    MNode* prev = NULL;

    if (temp->br == b) {
        head = temp->next;
        delete temp;
        cout << "Mobile Deleted!" << endl;
        return;
    }

    while (temp != NULL && temp->br != b) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Mobile Not Found!" << endl;
        return;
    }

    prev->next = temp->next;
    delete temp;
    cout << "Mobile Deleted!" << endl ;
}

void showMob() {
    if (head == NULL) {
        cout << "No Mobiles Available!" << endl;
        return;
    }

    MNode* temp = head;
    cout <<   endl << "*******Mobile List *******" << endl ;
    while (temp != NULL) {
        cout << " Brand: " << temp->br << endl 
             << " Stock " << temp->qty << endl 
             << " Price " << temp->price << endl;
        temp = temp->next;
    }
}

int main() {

    addMob("Vivo", 8, 55000);
    addMob("Oppo", 7,110000);
    addMob("Techno", 16, 80000);

    showMob();

    delMob("Vivo");

    showMob();

    return 0;
}