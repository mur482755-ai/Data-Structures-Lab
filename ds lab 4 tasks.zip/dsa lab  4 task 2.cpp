#include <iostream>
using namespace std;

struct ProfNode {
    string user;     
    int age;        
    string city;   
    ProfNode* next;
};

ProfNode* head = NULL;


void addProfile(string u, int a, string c) {
    ProfNode* newnode = new ProfNode;
   newnode->user = u;
    newnode->age = a;
    newnode->city = c;
   newnode->next = NULL;

    if (head == NULL) {
        head = newnode;
    } else {
        ProfNode* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newnode;
    }
}


void showProfiles() {
    if (head == NULL) {
        cout << "No Profiles Found" << endl;
        return;
    }

    ProfNode* temp = head;
    cout << "******* User Profiles *******" << endl;
    while (temp != NULL) {
        cout << "Name: " << temp->user << endl 
             << " Age: " << temp->age << endl
             << " City: " << temp->city << endl;
        temp = temp->next;
    }
}

int main() {

    addProfile("Ayehsa", 21, "Rawalpindi");
    addProfile("Asma", 23, "Lahore");
    addProfile("Fatima", 19, "Islamabad");

    showProfiles();

    return 0;
}