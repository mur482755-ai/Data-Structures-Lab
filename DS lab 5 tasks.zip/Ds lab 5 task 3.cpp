#include <iostream>
using namespace std;

struct PlayerNode {
    string name;
    int score;
    PlayerNode* prev;
    PlayerNode* next;
};

PlayerNode* first = NULL;

void addPlayer(string nm, int sc) {

    PlayerNode* node = new PlayerNode();

    node->name = nm;
    node->score = sc;

    if(first == NULL || sc < first->score) {

        node->next = first;
        node->prev = NULL;

        if(first != NULL)
            first->prev = node;

        first = node;
        return;
    }

    PlayerNode* temp = first;

    while(temp->next != NULL && temp->next->score < sc)
        temp = temp->next;

    node->next = temp->next;
    node->prev = temp;

    if(temp->next != NULL)
        temp->next->prev = node;

    temp->next = node;
}

void showPlayers() {

    PlayerNode* temp = first;

    cout<<"Players and Scores:"<<endl <<endl  ;

    while(temp != NULL) {
        cout<<temp->name<<" - "<<temp->score<<endl <<endl  ;
        temp = temp->next;
    }
}

int main() {

    addPlayer("Fatima",100);
    addPlayer("Anaya",12);
    addPlayer("Hadia",54);
    addPlayer("Aliya",23);

    showPlayers();
}