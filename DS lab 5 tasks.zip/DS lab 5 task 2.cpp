#include <iostream>
using namespace std;

struct RainNode {
    float rain;
    RainNode* prev;
    RainNode* next;
};

RainNode* first = NULL;

void addRain(float val) {

    if(val < 0) {
        cout<<"Invalid rainfall value"<<endl;
        return;
    }

    RainNode* node = new RainNode();

    node->rain = val;
    node->next = NULL;

    if(first == NULL) {
        node->prev = NULL;
        first = node;
        return;
    }

    RainNode* temp = first;

    while(temp->next != NULL)
        temp = temp->next;

    temp->next = node;
    node->prev = temp;
}

void rainfallStats() {

    RainNode* temp = first;

    float total = 0;
    float maxR = -1;
    float minR = 9999;

    int day = 1, maxDay, minDay;

    while(temp != NULL) {

        total += temp->rain;

        if(temp->rain > maxR) {
            maxR = temp->rain;
            maxDay = day;
        }

        if(temp->rain < minR) {
            minR = temp->rain;
            minDay = day;
        }

        temp = temp->next;
        day++;
    }

    cout<<"Total rainfall for the week = "<<total<<endl;
    cout<<"Average rainfall = "<<total/7<<endl;
    cout<<"Day with highest rainfall = "<<maxDay<<endl;
    cout<<"Day with lowest rainfall = "<<minDay<<endl;
}

void rainAfter5th() {

    RainNode* temp = first;

    for(int i=1;i<=5;i++)
        temp = temp->next;

    if(temp != NULL)
        cout<<"Rainfall after 5th day = "<<temp->rain<<endl;
}

int main() {

    float x;

    cout<<"Enter rainfall for 7 days:"<<endl;

    for(int i=0;i<7;i++) {
        cin>>x;
        addRain(x);
    }

    rainfallStats();
    rainAfter5th();
}