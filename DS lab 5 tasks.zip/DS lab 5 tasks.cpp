#include <iostream>
using namespace std;

struct MarksNode {
    int marks;
    MarksNode* prev;
    MarksNode* next;
};

MarksNode* start = NULL;

void insertStart(int val) {

    MarksNode* newNode = new MarksNode();

    newNode->marks = val;
    newNode->prev = NULL;
    newNode->next = start;

    if(start != NULL)
        start->prev = newNode;

    start = newNode;
}

void insertAfter45(int val) {

    MarksNode* current = start;

    while(current != NULL && current->marks != 45)
        current = current->next;

    if(current == NULL) {
        cout<<"Value 45 not found in list"<<endl;
        return;
    }

    MarksNode* newNode = new MarksNode();

    newNode->marks = val;
    newNode->next = current->next;
    newNode->prev = current;

    if(current->next != NULL)
        current->next->prev = newNode;

    current->next = newNode;
}

void removeStart() {

    if(start == NULL) return;

    MarksNode* temp = start;

    start = start->next;

    if(start != NULL)
        start->prev = NULL;

    delete temp;
}

void removeAfter45() {

    MarksNode* current = start;

    while(current != NULL && current->marks != 45)
        current = current->next;

    if(current == NULL || current->next == NULL)
        return;

    MarksNode* delNode = current->next;

    current->next = delNode->next;

    if(delNode->next != NULL)
        delNode->next->prev = current;

    delete delNode;
}

void showList() {

    MarksNode* ptr = start;

    cout<<"Doubly Linked List Data:"<<endl;

    while(ptr != NULL) {
        cout<<ptr->marks<<" <-> ";
        ptr = ptr->next;
    }

    cout<<"NULL"<<endl;
}

int main() {

    insertStart(12);
    insertStart(60);
    insertStart(45);
    insertStart(1);

    cout<<"Original List:"<<endl << endl ;
    
    showList();

    insertAfter45(90);
    
    cout<<"After inserting value after 45:"<<endl << endl ;
    
    showList();

    removeStart();
    
    cout<<"After removing first node:"<<endl << endl;
    
    showList();
    

    removeAfter45();
    
    cout<<"After removing node after 45:"<<endl << endl ;
    
    
    showList();
}