#include <iostream>
using namespace std;

struct node {
    int data;
    node* next;
};

class datalist {
private:
    node* head;

public:
    datalist() {
        head = NULL;
    }

    void adddata(int value) {
        node* newnode = new node{value, NULL};

        if (head == NULL) {
            head = newnode;
            newnode->next = head;
        } else {
            node* temp = head;

            while (temp->next != head)
                temp = temp->next;

            temp->next = newnode;
            newnode->next = head;
        }

        cout << "Data added successfully" << endl;
        cout << endl;
    }

    void deletedata(int value) {
        if (head == NULL) {
            cout << "The list is empty" << endl;
             cout << endl;
            return;
        }

        node* current = head;
        node* previous = NULL;

        if (head->data == value) {
            if (head->next == head) {
                delete head;
                head = NULL;
            } else {
                node* last = head;

                while (last->next != head)
                    last = last->next;

                last->next = head->next;
                node* temp = head;
                head = head->next;
                delete temp;
            }

            cout << "Data deleted successfully" << endl;
             cout << endl;
            return;
        }

        previous = head;
        current = head->next;

        while (current != head) {
            if (current->data == value) {
                previous->next = current->next;
                delete current;

                cout << "Data deleted successfully" << endl;
                 cout << endl;
                return;
            }

            previous = current;
            current = current->next;
        }

        cout << "Value cannot  be found" << endl;
         cout << endl;
    }

    void searchdata(int value) {
        if (head == NULL) {
            cout << "The list is empty" << endl;
             cout << endl;
            return;
        }

        node* temp = head;

        do {
            if (temp->data == value) {
                cout << "Value found in the list" << endl;
                 cout << endl;
                return;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "Value cannot  be found" << endl;
    }
};

int main() {
    datalist list;

    list.adddata(5);
    list.adddata(10);
    list.adddata(15);

    list.searchdata(10);
    list.deletedata(10);
    list.searchdata(10);

    return 0;
}