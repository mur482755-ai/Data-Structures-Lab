#include <iostream>
using namespace std;

struct node {
    int data;
    node* next;
};

class circularlinklist {
private:
    node* head;

public:
    circularlinklist() {
        head = NULL;
    }

    void insertbefore(int value) {
        node* newnode = new node{value, NULL};

        if (head == NULL) {
            head = newnode;
            newnode->next = head;
        } else {
            node* temp = head;

            while (temp->next != head)
                temp = temp->next;

            newnode->next = head;
            temp->next = newnode;
            head = newnode;
        }

        cout << "Node inserted at the beginning" << endl;
        cout << endl;
        
    }

    void insertafter(int value) {
        node* newnode = new node{value, NULL};

        if (head == NULL) {
            head = newnode;
            newnode->next = head;
        } else {
            node* temp = head;

            while (temp->next != head)
                temp = temp->next;

            temp->next = newnode;
            newnode->next = head;
        }

        cout << "Node inserted at the end" << endl;
        cout << endl;
    }

    void deletevalue(int value) {
        if (head == NULL) {
            cout << "The list is empty" << endl;
            cout << endl;
            return;
        }

        node* current = head;
        node* previous = NULL;

        if (head->data == value) {
            if (head->next == head) {
                delete head;
                head = NULL;
            } else {
                node* last = head;

                while (last->next != head)
                    last = last->next;

                last->next = head->next;
                node* temp = head;
                head = head->next;
                delete temp;
            }

            cout << "Node deleted successfully" << endl;
            cout << endl;
            return;
        }

        previous = head;
        current = head->next;

        while (current != head) {
            if (current->data == value) {
                previous->next = current->next;
                delete current;

                cout << "Node deleted successfully" << endl;
                cout << endl;
                return;
            }

            previous = current;
            current = current->next;
        }

        cout << "Value  cannot be found in the list" << endl;
    }

    void display() {
        if (head == NULL)
            return;

        node* temp = head;

        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);

        cout << endl;
    }
};

int main() {
    circularlinklist list;
	cout << endl;
    list.insertbefore(10);
    list.insertafter(20);
    list.insertafter(30);

    list.display();
	cout << endl;
    list.deletevalue(20);
    list.display();

    return 0;
}