#include <iostream>
using namespace std;

class book {
private:
    string bookid;
    string bookname;
    double bookprice;
    string bookauthor;

public:
    book() {}

    book(string id, string name, double price, string author) {
        bookid = id;
        bookname = name;
        bookprice = price;
        bookauthor = author;
    }

    string getid() { return bookid; }
    string getname() { return bookname; }
    double getprice() { return bookprice; }
    string getauthor() { return bookauthor; }

    void setname(string name) { bookname = name; }
    void setprice(double price) { bookprice = price; }
    void setauthor(string author) { bookauthor = author; }

    void display() {
        cout << "ID: " << bookid
             << ", Name: " << bookname
             << ", Price: " << bookprice
             << ", Author: " << bookauthor << endl;
    }
};

class booknode {
public:
    book data;
    booknode* next;
    booknode* prev;

    booknode(book b) {
        data = b;
        next = NULL;
        prev = NULL;
    }
};

class booklist {
private:
    booknode* head;

public:
    booklist() {
        head = NULL;
    }

    void addbook(string id, string name, double price, string author) {
        book b(id, name, price, author);
        booknode* newnode = new booknode(b);

        if (head == NULL) {
            head = newnode;
            head->next = head;
            head->prev = head;
        } else {
            booknode* last = head->prev;

            last->next = newnode;
            newnode->prev = last;
            newnode->next = head;
            head->prev = newnode;
        }

        cout << "Book added successfully" << endl;
    }

    void removebook(string id) {
        if (head == NULL)
            return;

        booknode* temp = head;

        do {
            if (temp->data.getid() == id) {

                if (temp->next == temp) {
                    head = NULL;
                } else {
                    temp->prev->next = temp->next;
                    temp->next->prev = temp->prev;

                    if (temp == head)
                        head = temp->next;
                }

                delete temp;
                cout << "Book removed successfully" << endl;
                return;
            }

            temp = temp->next;
        } while (temp != head);

        cout << "Book not found" << endl;
    }

    void updatebook(string id, string name, double price, string author) {
        if (head == NULL)
            return;

        booknode* temp = head;

        do {
            if (temp->data.getid() == id) {
                temp->data.setname(name);
                temp->data.setprice(price);
                temp->data.setauthor(author);

                cout << "Book updated successfully" << endl;
                return;
            }

            temp = temp->next;
        } while (temp != head);

        cout << "Book not found" << endl;
    }

    void printbooks() {
        if (head == NULL)
            return;

        booknode* temp = head;

        do {
            temp->data.display();
            temp = temp->next;
        } while (temp != head);
    }
};

int main() {
    booklist list;

    for (int i = 1; i <= 10; i++) {
        list.addbook("b" + to_string(i),
                     "book" + to_string(i),
                     i * 2000,
                     "author" + to_string(i));
    }
	cout << endl;
    cout << "List of books:" << endl;
    list.printbooks();

    return 0;
}