#include<iostream>
using namespace std;

int main(){
	
	char* ptr   = new char;
	
	cout << "Please enter a character " << endl;
	cin >> *ptr;
	
	cout << " The character Stored " << *ptr << endl;
	
	delete ptr;
	 ptr = nullptr;
	
	
	return 0;
	
}
