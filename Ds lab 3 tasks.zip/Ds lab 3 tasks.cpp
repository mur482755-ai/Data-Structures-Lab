#include <iostream>
using namespace std;

struct Product {
    string name;
    int code;
    float price;
};

int main() {
    int num;
    cout << "Enter total  number of products ";
    cin >> num;

    
    Product *pro = new Product[num];

    for (int i = 0; i < num; i++) {
    	cout << endl;
        cout << "Product " << i+1 << ":" << endl;
        cout << "Name: ";
        cin >> pro[i].name;
        cout << "Code: ";
        cin >> pro[i].code;
        cout << "Price: ";
        cin >> pro[i].price;
    }

   cout << endl;
    cout << "Product List"  << endl;
    for (int i = 0; i < num; i++) {
        cout << "Name: " << pro[i].name
             << ", Code: " << pro[i].code
             << ", Price: " << pro[i].price << endl;
    }

    delete[] pro;
    return 0;
    
}